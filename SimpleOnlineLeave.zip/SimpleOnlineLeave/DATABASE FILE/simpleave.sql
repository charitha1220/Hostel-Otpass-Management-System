-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2021 at 06:09 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `simpleave`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `security` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `security` (`id`, `name`, `email`, `password`) VALUES
(1, 'security', 'security@gmail.com', 'D00F5D5217896FB7FD601412CB890830');

-- --------------------------------------------------------

--
-- Table structure for table `leaves`
--

CREATE TABLE `leaves` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `leavedate` date NOT NULL,
  `leavereason` varchar(255) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leaves`
--

INSERT INTO `leaves` (`id`, `name`, `email`, `department`, `leavedate`, `leavereason`, `status`) VALUES
(1, 'charitha', 'charitha@gmail.com', 'COMPUTER SCIENCE', '2020-04-09', '<p>kabaddi tournament</p>\n', 1),
(2, 'priya', 'priya@gmail.com', 'COMPUTER SCIENCE', '2021-05-10', '<p>health issue</p>\r\n', 1),
(3, 'palvani', 'palvani@gmail.com', 'COMPUTER SCIENCE', '2021-05-30', '<p>home occasion</p>\r\n', 0),
(4, 'samantha', 'samantha@gmail.com', 'ECE', '2021-07-05', '<p>health issue</p>\r\n', 1),
(5, 'niveditha', 'nivi@gmail.com', 'ECE', '2021-07-06', '<p>none</p>\r\n', 1),
(6, 'latha', 'latha@gmail.com', 'CE', '2021-07-04', '<p>Dentist appointment</p>\r\n', 0),
(7, 'dharani', 'daru@gmail.com', 'EEE', '2021-07-07', '<p> hockey tournament</p>\r\n', 1),
(8, 'yuvarani', 'yuva@gmail.com', 'PUC', '2021-07-04', '<p>to attend cousin wedding</p>\r\n', 0),
(9, 'yuvana', 'yuna@gmail.com', 'MECH', '2021-07-03', '<p>none</p>\r\n', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(333) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `department`, `email`, `password`) VALUES
(1, 'yuvana', 'MECH', 'yuna@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99'),
(2, 'yuvarani', 'PUC', 'yuva@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99'),
(3, 'dharani', 'EEE', 'dharani@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99'),
(4, 'charitha', 'COMPUTER SCIENSCE', 'cherry@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99'),
(5, 'latha', 'CE', 'latha@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99'),
(6, 'priya', 'COMPUTER SCIENCE', 'priya@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99'),
(7, 'palvani', 'COMPUTER SCIENCE', 'palvani@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leaves`
--
ALTER TABLE `leaves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `leaves`
--
ALTER TABLE `leaves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

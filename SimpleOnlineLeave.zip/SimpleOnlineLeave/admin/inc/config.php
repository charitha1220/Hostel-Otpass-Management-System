<?php 
	$con = mysqli_connect('localhost','root','password@123A$','simpleave');
	if (!$con) {
		echo "Database Not Connected";
	}
 ?>
